import random
from my_pkg.midday_module import big_tipper, cartow, catch_Happy_hour, flat_tire, rando_venmo, walk_out
from my_pkg.morning_module import total, Avo_toast, smoothie, burrito, coffee, energy_drink, eat_at_work







total = 60


name = input("Welcome to the Millenial Nightmare. What is your name?")
print("hello", name,",Do you think you have what it takes to make it through the day?")
choice = int(input("1) yass queen \n2) I literally cannont even"))

class Decision:
    def __init__(self, name, total, choice):
        self.name = name
        self.total = total
        self.choice = choice

    def morning_choice(self, action):
        if action == 1 or action == "1":
            morning_list = [Avo_toast, smoothie, burrito]
            random.choice(morning_list)()

   
