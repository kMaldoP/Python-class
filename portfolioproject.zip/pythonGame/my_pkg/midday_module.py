                                        ##yes list 
total = 60
                            ## Yes List
def catch_Happy_hour():
    Happy_hour = 60
    global total
    total -= Happy_hour
    print(f"Half off your tab being industry, But those rumplemintz shots caught up to you and you had to uber home. That is going to set you back ${Happy_hour} dollars. \n You now have {total} dollars.")
    

def flat_tire():
    ftire = 70
    global total
    total -= ftire
    print(f"While in a hurry to get out of the parking lot you run over a curb and get a flat tire.\n You lose ${ftire}\n You now have {total} dollars")

def rando_venmo():
    venmo = 100
    global total
    total += venmo
    print(f"You get a text from your friend who has just remembered they needed to venmo you for last weeks dinner. You have been sent ${venmo} dollars.\n You now have ${total} dollars. #COMEUP")
                            ##end of yes list
                            ##no list

def walk_out():
    wlkout = 45
    global total
    total -= wlkout
    print(f"You attempt to stay and make some more money, but your last table dined and dashed, and you are stuck with the tab. This set you back {wlkout} dollars.\n You now have ${total}")


def big_tipper():
    btip = 50
    global total
    total += btip
    print(f"Taking that extra table before you left really paid off. \nYou recieved a tip of ${btip} bucks\n You know have ${total}")

def cartow():
    Car_towed = 200
    global total
    total -= Car_towed
    print(f"You offered to stay forgetting that you were in a paid parking space that you forgot to put more money into. Getting your car out of the tow yard is going to cost you -${Car_towed} dollars\nYou now have ${total}")