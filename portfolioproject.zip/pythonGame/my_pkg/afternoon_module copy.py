global total
total = 60

                            ##### Yes List

                                